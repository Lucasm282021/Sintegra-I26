(function () {
  'use strict';
  let registryPage = 1;

  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const cash = (v) => '$ ' + Number(v || 0).toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const date = (v) => v ? (Number.isNaN(new Date(v).getTime()) ? esc(v) : new Date(v).toLocaleDateString('es-AR')) : '—';
  const fullName = (c) => c.razon_social || [c.apellido, c.nombres].filter(Boolean).join(' ') || 'Sin nombre';
  const regimes = { monotributo: 'Monotributo', responsable_inscripto: 'Responsable Inscripto', exento: 'Exento', sin_inscripcion: 'Sin inscripción', consumidor_final: 'Consumidor Final' };
  const regimeName = (v) => regimes[v] || v || 'Sin inscripción';
  const qs = (o) => { const p = new URLSearchParams(); Object.keys(o).forEach((k) => { if (o[k] !== '' && o[k] != null) p.set(k, o[k]); }); return p.toString(); };
  async function api(path, method, body) { return (await window.ARCAApi.request(path, { method: method || 'GET', body: body || null })).data; }
  function msg(node, text, error) { node.className = 'feedback-banner ' + (error ? 'feedback-error' : 'feedback-success'); node.textContent = text; }
  function fail(node, e) { msg(node, e.message || 'No se pudo completar la operación.', true); }
  function validField(input, result) {
    if (!window.ARCAApi.isValidCuit(input.value.trim())) { msg(result, 'El CUIT debe tener 11 dígitos, prefijo admitido y dígito verificador correcto.', true); input.focus(); return false; }
    return true;
  }
  function tab(id) { const b = document.querySelector('.tab-btn[data-tab="' + id + '"]'); if (b && !b.hidden) b.click(); }
  function initArcaWorkspace(user) {
    window.ARCAApi.setActor(user.email);
    if (window.arcaWorkspaceInitialized) return;
    window.arcaWorkspaceInitialized = true;
    initPersonForm(); initRegistration(); initRegistry(); initRegime(); initCertificate(); initPvs(); initInvoices();
    document.getElementById('refreshDashboard').addEventListener('click', dashboard);
    dashboard(); registry(); invoiceList();
  }
  window.initArcaWorkspace = initArcaWorkspace;

  function initPersonForm() {
    const selector = document.getElementById('personType');
    function update() {
      const human = selector.value === 'humana';
      document.querySelectorAll('.human-fields').forEach((box) => { box.hidden = !human; box.querySelectorAll('input,select').forEach((x) => { x.required = human; }); });
      document.querySelectorAll('.legal-fields').forEach((box) => { box.hidden = human; box.querySelectorAll('input,select').forEach((x) => { x.required = !human && x.id !== 'prefijoCuit'; }); });
    }
    selector.addEventListener('change', update); update();
  }
  function initRegistration() {
    document.getElementById('contributorForm').addEventListener('submit', async (e) => {
      e.preventDefault(); const result = document.getElementById('contributorFormResult'); const human = document.getElementById('personType').value === 'humana';
      const b = { tipo_persona: human ? 'humana' : 'juridica', domicilio_fiscal: document.getElementById('domicilioFiscal').value.trim(), actividad_codigo: document.getElementById('actividadCodigo').value.trim(), actividad_descripcion: document.getElementById('actividadDescripcion').value.trim(), fecha_inicio_actividades: document.getElementById('inicioActividades').value, email_dfe: document.getElementById('emailDfe').value.trim() };
      if (human) Object.assign(b, { dni: document.getElementById('dni').value.trim(), apellido: document.getElementById('apellido').value.trim(), nombres: document.getElementById('nombres').value.trim(), sexo_registral: document.getElementById('sexoRegistral').value, fecha_nacimiento: document.getElementById('fechaNacimiento').value });
      else Object.assign(b, { razon_social: document.getElementById('razonSocial').value.trim(), tipo_sociedad: document.getElementById('tipoSociedad').value, fecha_contrato_social: document.getElementById('fechaContrato').value, registro_publico: document.getElementById('registroPublico').value.trim(), prefijo_cuit: document.getElementById('prefijoCuit').value });
      const required = human ? ['dni','apellido','nombres','fecha_nacimiento'] : ['razon_social','fecha_contrato_social','registro_publico'];
      if (required.some((k) => !b[k]) || !b.domicilio_fiscal || !b.actividad_codigo || !b.actividad_descripcion || !b.fecha_inicio_actividades || !b.email_dfe) return msg(result, 'Completá los campos obligatorios con datos ficticios.', true);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(b.email_dfe)) return msg(result, 'Ingresá un correo válido para el Domicilio Fiscal Electrónico.', true);
      try {
        const data = await api('/arca/contribuyentes', 'POST', b);
        msg(result, 'Alta ficticia creada. CUIT asignado: ' + data.contribuyente.cuit + '. Inscribí un régimen y un punto de venta antes de emitir.', false);
        e.currentTarget.reset(); document.getElementById('personType').value = 'humana'; document.getElementById('personType').dispatchEvent(new Event('change'));
        registry(); dashboard();
      } catch (error) { fail(result, error); }
    });
  }

  function initRegistry() {
    document.getElementById('registryFilters').addEventListener('submit', (e) => { e.preventDefault(); registryPage = 1; registry(); });
    document.getElementById('registryTable').addEventListener('click', async (e) => {
      const b = e.target.closest('[data-cuit-action]'); if (!b) return;
      const cuit = b.dataset.cuit;
      if (b.dataset.cuitAction === 'detail') detail(cuit);
      if (b.dataset.cuitAction === 'regime') { document.getElementById('regimeCuit').value = cuit; tab('tab-regimen'); showRegimeHistory(cuit); }
      if (b.dataset.cuitAction === 'pv') { document.getElementById('pvCuit').value = cuit; tab('tab-pv'); pvs(cuit); }
      if (b.dataset.cuitAction === 'certificate') { document.getElementById('certificateCuit').value = cuit; tab('tab-constancia'); document.getElementById('certificateForm').requestSubmit(); }
    });
    document.getElementById('registryPagination').addEventListener('click', (e) => { const b = e.target.closest('[data-page]'); if (b) { registryPage = Number(b.dataset.page); registry(); } });
  }
  async function registry() {
    const holder = document.getElementById('registryTable');
    const p = qs({ buscar: document.getElementById('registrySearch').value.trim(), estado: document.getElementById('registryState').value, regimen: document.getElementById('registryRegime').value, page: registryPage });
    try {
      const d = await api('/arca/contribuyentes?' + p); const rows = d.contribuyentes || [];
      holder.innerHTML = rows.length ? '<table class="data-grid"><thead><tr><th>CUIT</th><th>Contribuyente</th><th>Régimen</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>' + rows.map((c) => '<tr><td><code>' + esc(c.cuit) + '</code></td><td>' + esc(fullName(c)) + '</td><td>' + esc(regimeName(c.regimen && c.regimen.tipo)) + (c.regimen && c.regimen.categoria ? ' · ' + esc(c.regimen.categoria) : '') + '</td><td><span class="status-pill ' + esc(c.estado) + '">' + esc(c.estado) + '</span></td><td><div class="table-actions"><button class="btn-sm" data-cuit-action="detail" data-cuit="' + esc(c.cuit) + '">Ficha</button><button class="btn-sm" data-cuit-action="regime" data-cuit="' + esc(c.cuit) + '">Régimen</button><button class="btn-sm" data-cuit-action="pv" data-cuit="' + esc(c.cuit) + '">PV</button><button class="btn-sm" data-cuit-action="certificate" data-cuit="' + esc(c.cuit) + '">Constancia</button></div></td></tr>').join('') + '</tbody></table>' : '<div class="empty-state">No hay resultados con esos filtros.</div>';
      document.getElementById('registryPagination').innerHTML = '<button type="button" class="btn-sm" data-page="' + Math.max(1,d.pagina-1) + '" ' + (d.pagina <= 1 ? 'disabled' : '') + '>Anterior</button><span>Página ' + d.pagina + ' de ' + d.paginas + ' · ' + d.total + ' contribuyentes</span><button type="button" class="btn-sm" data-page="' + Math.min(d.paginas,d.pagina+1) + '" ' + (d.pagina >= d.paginas ? 'disabled' : '') + '>Siguiente</button>';
    } catch (e) { holder.textContent = e.message; }
  }
  function auditTable(rows) {
    return rows.length ? '<table class="data-grid"><thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Detalle</th></tr></thead><tbody>' + rows.map((r) => '<tr><td>' + date(r.fecha) + '</td><td>' + esc(r.actor) + '</td><td>' + esc(r.accion) + '</td><td>' + esc(r.detalle) + '</td></tr>').join('') + '</tbody></table>' : '<div class="empty-state">Sin operaciones registradas.</div>';
  }
  async function detail(cuit) {
    const box = document.getElementById('contributorDetail'); box.hidden = false; box.innerHTML = '<p>Cargando ficha…</p>';
    try {
      const c = await api('/arca/contribuyentes/' + encodeURIComponent(cuit));
      const fields = [['CUIT',c.cuit],['Tipo de persona',c.tipo_persona],['Nombre / razón social',fullName(c)],['DNI',c.dni],['Sociedad',c.tipo_sociedad],['Domicilio fiscal',c.domicilio_fiscal],['Actividad',(c.actividad_principal.codigo || '') + ' · ' + (c.actividad_principal.descripcion || '')],['Inicio de actividades',c.fecha_inicio_actividades],['Correo DFE',c.email_dfe],['Estado',c.estado],['Régimen',regimeName(c.regimen && c.regimen.tipo)],['Categoría ficticia',c.regimen && c.regimen.categoria]];
      box.innerHTML = '<div class="section-heading"><div><h2>Ficha · ' + esc(c.cuit) + '</h2><p class="section-desc">Información ficticia y auditoría académica.</p></div><button type="button" id="closeDetail" class="btn-sm">Cerrar</button></div><div class="detail-grid">' + fields.filter((x) => x[1] != null && x[1] !== '').map((x) => '<div class="detail-field"><small>' + esc(x[0]) + '</small><strong>' + esc(x[1]) + '</strong></div>').join('') + '</div><h3 class="subsection-title">Modificar domicilio, actividad o correo</h3><form id="editContributorForm" class="form-grid"><label>Domicilio fiscal<input name="domicilio_fiscal" value="' + esc(c.domicilio_fiscal) + '" required></label><label>Código de actividad<input name="actividad_codigo" value="' + esc(c.actividad_principal.codigo || '') + '" required></label><label>Descripción de actividad<input name="actividad_descripcion" value="' + esc(c.actividad_principal.descripcion || '') + '" required></label><label>Correo DFE<input name="email_dfe" type="email" value="' + esc(c.email_dfe) + '" required></label><button class="btn btn-primary full-width">Guardar cambios</button></form><form id="stateForm" class="filter-row"><label>Estado<select name="estado"><option value="activo" ' + (c.estado === 'activo' ? 'selected' : '') + '>Activo</option><option value="suspendido" ' + (c.estado === 'suspendido' ? 'selected' : '') + '>Suspendido</option><option value="baja" ' + (c.estado === 'baja' ? 'selected' : '') + '>Baja</option></select></label><label>Motivo ficticio<input name="motivo" required maxlength="180"></label><button class="btn btn-secondary">Actualizar estado</button></form><h3>Historial y auditoría</h3>' + auditTable(c.auditoria || []);
      box.querySelector('#closeDetail').addEventListener('click', () => { box.hidden = true; });
      box.querySelector('#editContributorForm').addEventListener('submit', async (e) => {
        e.preventDefault(); const d = new FormData(e.currentTarget);
        try { await api('/arca/contribuyentes/' + encodeURIComponent(cuit), 'PATCH', { domicilio_fiscal:d.get('domicilio_fiscal'), email_dfe:d.get('email_dfe'), actividad_principal:{ codigo:d.get('actividad_codigo'), descripcion:d.get('actividad_descripcion') } }); await detail(cuit); registry(); }
        catch (err) { alert(err.message); }
      });
      box.querySelector('#stateForm').addEventListener('submit', async (e) => {
        e.preventDefault(); const d = new FormData(e.currentTarget);
        try { await api('/arca/contribuyentes/' + encodeURIComponent(cuit) + '/estado', 'POST', { estado:d.get('estado'), motivo:d.get('motivo') }); await detail(cuit); registry(); dashboard(); }
        catch (err) { alert(err.message); }
      });
    } catch (e) { box.textContent = e.message; }
  }
  async function dashboard() {
    try {
      const d = await api('/arca/panel');
      const totalPeople = Object.values(d.contribuyentes_por_regimen).reduce((a,b) => a + b, 0);
      const cards = [['Altas este mes',d.altas_mes],['Contribuyentes',totalPeople],['Comprobantes hoy',d.comprobantes_hoy],['Total facturado',cash(d.total_facturado)]];
      document.getElementById('dashboardMetrics').innerHTML = cards.map((x) => '<div class="metric-card"><span>' + esc(x[0]) + '</span><strong>' + esc(x[1]) + '</strong></div>').join('');
      const stats = Object.entries(d.contribuyentes_por_regimen).map((x) => regimeName(x[0]) + ': ' + x[1]).join(' · ');
      document.getElementById('dashboardRecent').innerHTML = '<p class="help-text">Por régimen: ' + esc(stats || 'sin datos') + '</p>' + auditTable(d.ultimas_operaciones || []);
    } catch (e) { document.getElementById('dashboardMetrics').textContent = e.message; }
  }

  function initRegime() {
    const form = document.getElementById('regimeForm'); const type = document.getElementById('regimeType'); const amount = document.getElementById('annualEstimate'); const categories = window.ARCAApi.categories();
    document.getElementById('categoryTable').innerHTML = '<table class="data-grid"><thead><tr><th>Categoría</th><th>Tope anual ficticio</th></tr></thead><tbody>' + categories.map((c) => '<tr><td>' + c.category + '</td><td>' + cash(c.limit) + '</td></tr>').join('') + '</tbody></table>';
    function preview() {
      document.getElementById('annualEstimateGroup').hidden = type.value !== 'monotributo';
      const box = document.getElementById('categoryPreview');
      if (type.value !== 'monotributo') { box.textContent = 'Este régimen no usa categoría de Monotributo.'; return; }
      const value = Number(amount.value || 0); const c = categories.find((x) => value <= x.limit) || categories[categories.length - 1];
      box.textContent = 'Categoría sugerida ' + c.category + ' · tope anual ficticio ' + cash(c.limit) + (value > c.limit ? ' · supera el tope superior de ejemplo' : '');
    }
    type.addEventListener('change', preview); amount.addEventListener('input', preview); preview();
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); const input = document.getElementById('regimeCuit'); const result = document.getElementById('regimeResult');
      if (!validField(input,result)) return;
      try { const d = await api('/arca/contribuyentes/' + input.value.trim() + '/regimen','POST',{ tipo:type.value, facturacion_anual_estimada:type.value === 'monotributo' ? Number(amount.value) : 0 }); const r = d.contribuyente.regimen; msg(result,'Régimen simulado guardado: ' + regimeName(r.tipo) + (r.categoria ? ' · categoría ' + r.categoria : '') + '.',false); showRegimeHistory(input.value.trim()); registry(); dashboard(); }
      catch (err) { fail(result,err); }
    });
  }
  async function showRegimeHistory(cuit) {
    const box = document.getElementById('regimeHistory');
    try { const c = await api('/arca/contribuyentes/' + encodeURIComponent(cuit)); const rows = c.historial_regimen || [];
      box.innerHTML = '<h3>Historial de régimen · ' + esc(cuit) + '</h3>' + (rows.length ? '<table class="data-grid"><thead><tr><th>Fecha</th><th>Anterior</th><th>Nuevo</th><th>Usuario</th></tr></thead><tbody>' + rows.map((r) => '<tr><td>' + date(r.fecha) + '</td><td>' + esc(regimeName(r.anterior && r.anterior.tipo)) + '</td><td>' + esc(regimeName(r.nuevo && r.nuevo.tipo) + (r.nuevo && r.nuevo.categoria ? ' · ' + r.nuevo.categoria : '')) + '</td><td>' + esc(r.actor) + '</td></tr>').join('') + '</tbody></table>' : '<div class="empty-state">Sin historial todavía.</div>');
    } catch (e) { box.textContent = e.message; }
  }

  function initCertificate() {
    document.getElementById('certificateForm').addEventListener('submit', async (e) => {
      e.preventDefault(); const input = document.getElementById('certificateCuit'); const result = document.getElementById('certificateResult');
      if (!validField(input,result)) return;
      try {
        const d = await api('/arca/contribuyentes/' + encodeURIComponent(input.value.trim()) + '/constancia'); const c = d.contribuyente;
        const values = [['CUIT',c.cuit],['Nombre / razón social',fullName(c)],['Estado',c.estado],['Condición frente al IVA',regimeName(c.regimen && c.regimen.tipo)],['Régimen',regimeName(c.regimen && c.regimen.tipo)],['Categoría Monotributo',c.regimen && c.regimen.categoria || 'No corresponde'],['Actividad',(c.actividad_principal.codigo || '') + ' · ' + c.actividad_principal.descripcion],['Domicilio fiscal',c.domicilio_fiscal],['Correo DFE',c.email_dfe]];
        result.innerHTML = '<div id="certificatePrintable" class="certificate-sheet print-target"><p class="simulated-label">SIMULACIÓN ACADÉMICA · SIN VALIDEZ FISCAL</p><h3>Constancia de inscripción</h3><p>Emitida el ' + date(d.emitida_en) + '</p><hr><div class="detail-grid">' + values.map((x) => '<div class="detail-field"><small>' + esc(x[0]) + '</small><strong>' + esc(x[1]) + '</strong></div>').join('') + '</div><p class="academic-print-warning">Documento ficticio para una actividad académica. No acredita inscripción ante organismos oficiales.</p></div><button id="printCertificate" type="button" class="btn btn-secondary no-print">Imprimir / Guardar PDF</button>';
        document.getElementById('printCertificate').addEventListener('click', () => printBlock('certificatePrintable'));
      } catch (err) { fail(result,err); }
    });
  }
  function printBlock(id) {
    document.body.classList.remove('print-certificate','print-invoice');
    const block = document.getElementById(id); if (!block) return;
    document.querySelectorAll('.print-target').forEach((x) => x.classList.remove('print-target')); block.classList.add('print-target');
    document.body.classList.add(id === 'certificatePrintable' ? 'print-certificate' : 'print-invoice');
    window.print(); window.setTimeout(() => document.body.classList.remove('print-certificate','print-invoice'),500);
  }

  function initPvs() {
    const cuit = document.getElementById('pvCuit'); const form = document.getElementById('pvForm'); const result = document.getElementById('pvResult');
    cuit.addEventListener('change', () => pvs(cuit.value.trim()));
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); if (!validField(cuit,result)) return;
      try { const d = await api('/arca/contribuyentes/' + encodeURIComponent(cuit.value.trim()) + '/puntos-venta','POST',{ numero:document.getElementById('pvNumber').value.trim(), sistema_emision:document.getElementById('pvSystem').value, domicilio:document.getElementById('pvAddress').value.trim() }); msg(result,'Punto de venta ficticio ' + d.punto_venta.numero + ' dado de alta.',false); pvs(cuit.value.trim()); registry(); }
      catch (err) { fail(result,err); }
    });
    document.getElementById('pvList').addEventListener('click', async (e) => {
      const b = e.target.closest('[data-pv-close]'); if (!b) return;
      try { await api('/arca/contribuyentes/' + encodeURIComponent(cuit.value.trim()) + '/puntos-venta','POST',{ numero:b.dataset.pvClose, activo:false }); pvs(cuit.value.trim()); }
      catch (err) { fail(result,err); }
    });
  }
  async function pvs(cuit) {
    const box = document.getElementById('pvList');
    if (!cuit || !window.ARCAApi.isValidCuit(cuit)) { box.innerHTML = '<div class="empty-state">Ingresá un CUIT válido.</div>'; return; }
    try { const d = await api('/arca/contribuyentes/' + encodeURIComponent(cuit) + '/puntos-venta'); const rows = d.puntos_venta || [];
      box.innerHTML = rows.length ? '<table class="data-grid"><thead><tr><th>Número</th><th>Sistema</th><th>Domicilio</th><th>Estado</th><th></th></tr></thead><tbody>' + rows.map((p) => '<tr><td>' + esc(p.numero) + '</td><td>' + esc(p.sistema_emision) + '</td><td>' + esc(p.domicilio) + '</td><td>' + (p.activo ? 'Activo' : 'Baja') + '</td><td>' + (p.activo ? '<button class="btn-sm" data-pv-close="' + esc(p.numero) + '">Dar de baja</button>' : '') + '</td></tr>').join('') + '</tbody></table>' : '<div class="empty-state">Sin puntos de venta.</div>';
    } catch (e) { box.textContent = e.message; }
  }

  function itemRow() {
    const row = document.createElement('div'); row.className = 'invoice-item-row';
    row.innerHTML = '<label>Descripción<input data-item="descripcion" maxlength="120" placeholder="Producto o servicio" required></label><label>Cantidad<input data-item="cantidad" type="number" min="0.001" step="0.001" value="1" required></label><label>Precio unitario ($)<input data-item="precio_unitario" type="number" min="0.01" step="0.01" required></label><label>IVA<select data-item="alicuota_iva"><option value="21">21 %</option><option value="10.5">10,5 %</option><option value="27">27 %</option><option value="0">0 %</option></select></label><button type="button" class="btn-sm remove-item">Quitar</button>';
    return row;
  }
  function initInvoices() {
    const form = document.getElementById('invoiceForm'); const items = document.getElementById('invoiceItems'); const result = document.getElementById('invoiceResult');
    const issuer = document.getElementById('invoiceIssuer'); const receiverKind = document.getElementById('receiverKind');
    document.getElementById('invoiceSaleId').value = 'venta-' + Date.now(); items.appendChild(itemRow());
    document.getElementById('newSaleId').addEventListener('click', () => { document.getElementById('invoiceSaleId').value = 'venta-' + Date.now() + '-' + Math.floor(Math.random()*1000); });
    document.getElementById('addInvoiceItem').addEventListener('click', () => { items.appendChild(itemRow()); recalc(); });
    items.addEventListener('input', recalc); items.addEventListener('change', recalc);
    items.addEventListener('click', (e) => { if (e.target.closest('.remove-item') && items.children.length > 1) { e.target.closest('.invoice-item-row').remove(); recalc(); } });
    receiverKind.addEventListener('change', () => { const dni = receiverKind.value === 'dni'; document.getElementById('receiverCuitGroup').hidden = dni; document.getElementById('receiverDniGroup').hidden = !dni; document.getElementById('invoiceReceiverCuit').required = !dni; document.getElementById('invoiceReceiverDni').required = dni; invoiceType(); });
    document.getElementById('invoiceReceiverCuit').addEventListener('change', invoiceType);
    issuer.addEventListener('change', async () => { await loadPvs(); invoiceType(); });
    populateIssuers(); refreshNotes(); recalc();
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); const receiver = document.getElementById('invoiceReceiverCuit');
      if (!issuer.value) return msg(result,'No hay emisor habilitado. Inscribí el régimen y el punto de venta.',true);
      if (receiverKind.value === 'cuit' && !validField(receiver,result)) return;
      const sums = recalc();
      const rowItems = Array.from(items.querySelectorAll('.invoice-item-row')).map((row) => ({ descripcion:row.querySelector('[data-item="descripcion"]').value.trim(), cantidad:Number(row.querySelector('[data-item="cantidad"]').value), precio_unitario:Number(row.querySelector('[data-item="precio_unitario"]').value), alicuota_iva:Number(row.querySelector('[data-item="alicuota_iva"]').value) }));
      if (rowItems.some((x) => !x.descripcion || !x.cantidad || !x.precio_unitario)) return msg(result,'Completá descripción, cantidad y precio de cada ítem.',true);
      const body = { id_venta:document.getElementById('invoiceSaleId').value.trim(), cuit:issuer.value, punto_venta:document.getElementById('invoicePv').value, receptor_tipo:receiverKind.value, items:rowItems, monto_total:sums.total };
      if (receiverKind.value === 'dni') body.receptor_dni = document.getElementById('invoiceReceiverDni').value.trim(); else body.receptor_cuit = receiver.value.trim();
      try { const data = await api('/arca/comprobantes','POST',body); renderInvoice(data,result,Boolean(data.idempotente)); refreshNotes(); invoiceList(); dashboard(); }
      catch (err) { fail(result,err); }
    });
    document.getElementById('noteForm').addEventListener('submit', async (e) => {
      e.preventDefault(); const id = document.getElementById('noteInvoice').value; const box = document.getElementById('noteResult');
      if (!id) return msg(box,'Emití una factura para poder asociar una nota.',true);
      const kind = document.getElementById('noteKind').value;
      try { const n = await api('/arca/comprobantes/' + encodeURIComponent(id) + '/nota-' + kind,'POST',{ monto_total:Number(document.getElementById('noteAmount').value), motivo:document.getElementById('noteReason').value.trim() }); renderInvoice(n,box,false); refreshNotes(); invoiceList(); dashboard(); }
      catch (err) { fail(box,err); }
    });
    document.getElementById('noteInvoice').addEventListener('change', async (e) => {
      if (!e.target.value) return;
      try { const i = await api('/arca/comprobantes/' + encodeURIComponent(e.target.value)); document.getElementById('noteAmount').value = Number(i.monto_total).toFixed(2); } catch (_e) {}
    });
    document.getElementById('invoiceFilters').addEventListener('submit', (e) => { e.preventDefault(); invoiceList(); });
    document.getElementById('invoiceList').addEventListener('click', async (e) => {
      const b = e.target.closest('[data-invoice-id]'); if (!b) return;
      try { const i = await api('/arca/comprobantes/' + encodeURIComponent(b.dataset.invoiceId)); renderInvoice(i,document.getElementById('invoiceDetail'),false); } catch (err) { document.getElementById('invoiceDetail').textContent = err.message; }
    });
  }
  async function populateIssuers() {
    const select = document.getElementById('invoiceIssuer');
    try {
      let rows = []; let page = 1; let pages = 1;
      do { const d = await api('/arca/contribuyentes?' + qs({ estado:'activo', page:page })); rows = rows.concat(d.contribuyentes); pages = d.paginas; page += 1; } while (page <= pages);
      rows = rows.filter((c) => c.estado === 'activo' && c.regimen && ['monotributo','responsable_inscripto'].includes(c.regimen.tipo));
      select.innerHTML = '<option value="">Elegí emisor</option>' + rows.map((c) => '<option value="' + esc(c.cuit) + '" data-regimen="' + esc(c.regimen.tipo) + '">' + esc(fullName(c) + ' · ' + c.cuit + ' · ' + regimeName(c.regimen.tipo)) + '</option>').join('');
      loadPvs();
    } catch (_e) { select.innerHTML = '<option value="">No se pudo cargar el padrón</option>'; }
  }
  async function loadPvs() {
    const cuit = document.getElementById('invoiceIssuer').value; const select = document.getElementById('invoicePv');
    if (!cuit) { select.innerHTML = '<option value="">Elegí emisor</option>'; return; }
    try { const d = await api('/arca/contribuyentes/' + encodeURIComponent(cuit) + '/puntos-venta'); const pvs = d.puntos_venta.filter((p) => p.activo); select.innerHTML = pvs.length ? pvs.map((p) => '<option value="' + esc(p.numero) + '">' + esc(p.numero + ' · ' + p.sistema_emision) + '</option>').join('') : '<option value="">Sin puntos activos</option>'; }
    catch (e) { select.innerHTML = '<option value="">' + esc(e.message) + '</option>'; }
  }
  async function invoiceType() {
    const issuer = document.getElementById('invoiceIssuer').selectedOptions[0]; const box = document.getElementById('invoiceTypePreview');
    if (!issuer || !issuer.value) { box.textContent = 'Elegí emisor y receptor.'; recalc(); return; }
    let recipientRegime = 'consumidor_final';
    if (document.getElementById('receiverKind').value === 'cuit') {
      const cuit = document.getElementById('invoiceReceiverCuit').value.trim();
      if (!window.ARCAApi.isValidCuit(cuit)) { box.textContent = 'Ingresá CUIT receptor válido del padrón.'; recalc(); return; }
      try { const c = await api('/arca/contribuyentes/' + encodeURIComponent(cuit)); recipientRegime = c.regimen && c.regimen.tipo || 'sin_inscripcion'; }
      catch (e) { box.textContent = e.message; recalc(); return; }
    }
    const type = issuer.dataset.regimen === 'monotributo' ? 'FACTURA_C' : (recipientRegime === 'responsable_inscripto' ? 'FACTURA_A' : 'FACTURA_B');
    box.textContent = type.replace('_',' ') + ' · asignación automática'; if (type === 'FACTURA_C') document.querySelectorAll('[data-item="alicuota_iva"]').forEach((x) => { x.value = '0'; }); recalc();
  }
  function recalc() {
    const isC = document.getElementById('invoiceTypePreview').textContent.indexOf('FACTURA C') >= 0; let net = 0; let iva = 0;
    document.querySelectorAll('.invoice-item-row').forEach((row) => {
      const q = Number(row.querySelector('[data-item="cantidad"]').value || 0); const p = Number(row.querySelector('[data-item="precio_unitario"]').value || 0);
      const rate = isC ? 0 : Number(row.querySelector('[data-item="alicuota_iva"]').value || 0); const line = Math.round(q*p*100)/100; net += line; iva += Math.round(line*rate)/100;
    });
    net = Math.round(net*100)/100; iva = Math.round(iva*100)/100; const total = Math.round((net+iva)*100)/100;
    document.getElementById('invoiceTotals').innerHTML = '<span>Neto: <strong>' + cash(net) + '</strong></span><span>IVA: <strong>' + cash(iva) + '</strong></span><span>Total: <strong>' + cash(total) + '</strong></span>';
    return { neto:net, iva:iva, total:total };
  }
  async function refreshNotes() {
    const select = document.getElementById('noteInvoice'); if (!select) return;
    try { const d = await api('/arca/comprobantes'); const rows = d.comprobantes.filter((i) => i.tipo_comprobante.indexOf('FACTURA_') === 0); select.innerHTML = '<option value="">Elegí factura</option>' + rows.map((i) => '<option value="' + esc(i.id) + '">' + esc(i.tipo_comprobante + ' ' + i.punto_venta + '-' + i.numero_comprobante + ' · ' + cash(i.monto_total)) + '</option>').join(''); }
    catch (_e) { select.innerHTML = '<option value="">Sin facturas</option>'; }
  }
  function renderInvoice(i, box, repeated) {
    const items = (i.items || []).map((x) => '<tr><td>' + esc(x.descripcion) + '</td><td>' + esc(x.cantidad) + '</td><td>' + cash(x.precio_unitario) + '</td><td>' + esc(x.alicuota_iva) + '%</td><td>' + cash(x.neto) + '</td><td>' + cash(x.iva) + '</td><td>' + cash(x.total) + '</td></tr>').join('');
    box.innerHTML = '<div id="invoicePrintable" class="invoice-document print-target"><p class="simulated-label">CAE FICTICIO · SIN VALIDEZ FISCAL</p><div class="section-heading"><div><h3>' + esc(i.tipo_comprobante.replaceAll('_',' ')) + '</h3><p>PV ' + esc(i.punto_venta) + ' · N.º ' + esc(i.numero_comprobante) + '</p></div><span>' + (repeated ? 'Reintento idempotente · mismo comprobante' : 'Comprobante simulado') + '</span></div><p><strong>Emisor:</strong> ' + esc(i.cuit) + ' · <strong>Receptor:</strong> ' + esc(i.receptor_cuit || ('Consumidor final · DNI ' + i.receptor_dni)) + '</p><p><strong>Fecha:</strong> ' + date(i.fecha_emision) + ' · <strong>Vencimiento CAE:</strong> ' + date(i.fecha_vencimiento_cae) + '</p><div class="table-wrap"><table class="data-grid"><thead><tr><th>Descripción</th><th>Cant.</th><th>Precio</th><th>IVA</th><th>Neto</th><th>IVA $</th><th>Total</th></tr></thead><tbody>' + items + '</tbody></table></div><p>Neto ' + cash(i.neto) + ' · IVA ' + cash(i.iva) + ' · <strong>Total ' + cash(i.monto_total) + '</strong></p><p><strong>CAE:</strong> <code>' + esc(i.cae) + '</code></p><div class="qr-area">' + (i.qr_data_url ? '<img class="qr-code" alt="QR ficticio del comprobante" src="' + esc(i.qr_data_url) + '"><p>QR de simulación académica</p>' : '<p>No se recibió el QR de la API local.</p>') + '</div><p class="academic-print-warning">Comprobante y autorización ficticios. No tienen validez fiscal ni impositiva.</p></div><button id="printInvoice" type="button" class="btn btn-secondary no-print">Imprimir / Guardar PDF</button>';
    document.getElementById('printInvoice').addEventListener('click', () => printBlock('invoicePrintable'));
  }
  async function invoiceList() {
    const p = qs({ cuit:document.getElementById('filterIssuerCuit').value.trim(), receptor:document.getElementById('filterReceiverCuit').value.trim(), desde:document.getElementById('filterFrom').value, hasta:document.getElementById('filterTo').value, tipo:document.getElementById('filterInvoiceType').value, punto_venta:document.getElementById('filterPv').value.trim(), numero:document.getElementById('filterNumber') ? document.getElementById('filterNumber').value.trim() : '' });
    try {
      const d = await api('/arca/comprobantes?' + p); const rows = d.comprobantes || [];
      document.getElementById('invoicePeriodTotals').textContent = rows.length + ' comprobante(s) · total filtrado: ' + cash(d.total) + ' · importes ficticios.';
      document.getElementById('invoiceList').innerHTML = rows.length ? '<table class="data-grid"><thead><tr><th>Fecha</th><th>Tipo / número</th><th>Emisor</th><th>Receptor</th><th>PV</th><th>Total</th><th>Estado</th><th></th></tr></thead><tbody>' + rows.map((i) => '<tr><td>' + date(i.fecha_emision) + '</td><td>' + esc(i.tipo_comprobante + ' ' + i.numero_comprobante) + '</td><td>' + esc(i.cuit) + '</td><td>' + esc(i.receptor_cuit || ('DNI ' + i.receptor_dni)) + '</td><td>' + esc(i.punto_venta) + '</td><td>' + cash(i.monto_total) + '</td><td>' + esc(i.estado) + '</td><td><button class="btn-sm" data-invoice-id="' + esc(i.id) + '">Ver / imprimir</button></td></tr>').join('') + '</tbody></table>' : '<div class="empty-state">No hay comprobantes con esos filtros.</div>';
    } catch (e) { document.getElementById('invoiceList').textContent = e.message; }
  }
}());
