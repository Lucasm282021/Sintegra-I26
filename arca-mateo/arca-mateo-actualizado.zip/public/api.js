/*
 * ARCA API adapter.
 * MOCK_MODE keeps the academic demo local. When the course backend is ready,
 * set MOCK_MODE=false and configure API_BASE_URL here; the UI keeps using the same routes.
 */
(function () {
  'use strict';

  const MOCK_MODE = true;
  const API_BASE_URL = window.ARCA_API_BASE_URL || '';
  const STORAGE_KEY = 'arca-academico-mock-v2';
  const WEIGHTS = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
  const PREFIXES = ['20', '23', '27', '30', '33'];
  const CATEGORY_LIMITS = [
    { category: 'A', limit: 6000000 }, { category: 'B', limit: 9000000 },
    { category: 'C', limit: 13000000 }, { category: 'D', limit: 16000000 },
    { category: 'E', limit: 19000000 }, { category: 'F', limit: 24000000 },
    { category: 'G', limit: 29000000 }, { category: 'H', limit: 35000000 },
    { category: 'I', limit: 40000000 }, { category: 'J', limit: 45000000 },
    { category: 'K', limit: 50000000 }
  ];

  class ApiError extends Error {
    constructor(status, message) { super(message); this.status = status; }
  }

  function uid() {
    return window.crypto && crypto.randomUUID ? crypto.randomUUID() : 'arca-' + Date.now() + '-' + Math.random().toString(16).slice(2);
  }
  function isoNow() { return new Date().toISOString(); }
  function validCuit(value) {
    if (typeof value !== 'string' || !/^\d{11}$/.test(value) || !PREFIXES.includes(value.slice(0, 2))) return false;
    const sum = value.slice(0, 10).split('').reduce((n, d, i) => n + Number(d) * WEIGHTS[i], 0);
    const digit = 11 - (sum % 11);
    return digit !== 10 && Number(value[10]) === (digit === 11 ? 0 : digit);
  }
  function checksum(prefix, body) {
    const base = prefix + body;
    const sum = base.split('').reduce((n, d, i) => n + Number(d) * WEIGHTS[i], 0);
    const digit = 11 - (sum % 11);
    if (digit === 10) return null;
    return base + (digit === 11 ? '0' : String(digit));
  }
  function makeCuit(person) {
    if (person.tipo_persona === 'humana') {
      const dni = String(person.dni || '').replace(/\D/g, '').padStart(8, '0');
      if (dni.length !== 8) throw new ApiError(400, 'El DNI debe tener hasta 8 dígitos.');
      let prefix = person.sexo_registral === 'masculino' ? '20' : person.sexo_registral === 'femenino' ? '27' : '23';
      let cuit = checksum(prefix, dni);
      if (!cuit && prefix !== '23') { prefix = '23'; cuit = checksum(prefix, dni); }
      if (!cuit) throw new ApiError(400, 'No se pudo calcular un CUIT ficticio para ese DNI; revisá los datos y volvé a intentar.');
      return cuit;
    }
    const prefix = person.prefijo_cuit === '33' ? '33' : '30';
    const state = readState();
    let assigned = Number(state.next_society_number || 1);
    while (assigned < 99999999) {
      const cuit = checksum(prefix, String(assigned).padStart(8, '0'));
      assigned += 1;
      if (cuit && !state.contribuyentes[cuit]) {
        state.next_society_number = assigned;
        writeState(state);
        return cuit;
      }
    }
    throw new ApiError(409, 'No quedan números ficticios disponibles para asignar.');
  }
  function seedContributor(cuit, data) {
    return Object.assign({
      cuit: cuit, estado: 'activo', tipo_persona: cuit.slice(0, 2) === '30' ? 'juridica' : 'humana',
      domicilio_fiscal: 'Av. Ejemplo 123, Ciudad',
      actividad_principal: { codigo: '620100', descripcion: 'Servicios informáticos de prueba' },
      fecha_inicio_actividades: '2025-03-01', email_dfe: 'demo@arca.local',
      creado_en: isoNow(), creado_por: 'Datos de demostración', historial_regimen: [],
      puntos_venta: [{ numero: '00001', sistema_emision: 'web', domicilio: 'Av. Ejemplo 123, Ciudad', activo: true, creado_en: isoNow() }]
    }, data, { cuit: cuit });
  }
  function initialState() {
    const ri = seedContributor('30712345671', {
      tipo_persona: 'juridica', razon_social: 'Comercial del Sur S.A. (ficticia)', tipo_sociedad: 'SA',
      fecha_contrato_social: '2022-04-12', registro_publico: 'IGJ ficticia', estado: 'activo',
      regimen: { tipo: 'responsable_inscripto', categoria: null, facturacion_anual_estimada: 0, desde: isoNow() }
    });
    const mono = seedContributor('20301234563', {
      tipo_persona: 'humana', apellido: 'Pérez (ficticio)', nombres: 'Alex', dni: '30123456',
      sexo_registral: 'masculino', fecha_nacimiento: '1990-02-10', estado: 'activo',
      regimen: { tipo: 'monotributo', categoria: 'A', facturacion_anual_estimada: 4200000, limite_anual_ficticio: 6000000, desde: isoNow() }
    });
    return { contributors: { [ri.cuit]: ri, [mono.cuit]: mono }, invoices: [], audit: [], next_society_number: 1 };
  }
  function readState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const state = JSON.parse(raw);
        if (state && state.contributors && state.invoices && state.audit) return state;
      }
    } catch (_error) { /* El almacenamiento dañado se reinicia con datos de ejemplo. */ }
    const state = initialState();
    writeState(state);
    return state;
  }
  function writeState(state) { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  function actor() { return window.arcaCurrentActor || 'Equipo ARCA'; }
  function audit(state, cuit, accion, detalle) {
    state.audit.unshift({ id: uid(), cuit: cuit || '', actor: actor(), accion: accion, detalle: detalle || '', fecha: isoNow() });
    state.audit = state.audit.slice(0, 500);
  }
  function normRegime(tipo) { return tipo || 'sin_inscripcion'; }
  function categoryFor(amount) {
    const value = Number(amount);
    return CATEGORY_LIMITS.find((x) => value <= x.limit) || CATEGORY_LIMITS[CATEGORY_LIMITS.length - 1];
  }
  function jsonResponse(status, data) { return { status: status, data: data }; }
  function requireCuit(cuit) {
    if (!validCuit(cuit)) throw new ApiError(400, 'El CUIT debe tener 11 dígitos y un dígito verificador válido.');
  }
  function requireContributor(state, cuit) {
    requireCuit(cuit);
    const contributor = state.contributors[cuit];
    if (!contributor) throw new ApiError(404, 'Contribuyente no encontrado en el padrón académico.');
    return contributor;
  }
  function pathParts(path) {
    const url = new URL(path, window.location.origin);
    return { pathname: decodeURI(url.pathname), query: url.searchParams };
  }
  function money(value) {
    const number = Number(value);
    if (!Number.isFinite(number) || number <= 0 || Math.round(number * 100) !== number * 100) throw new ApiError(400, 'El monto debe ser positivo y tener hasta 2 decimales.');
    return Math.round(number * 100) / 100;
  }
  function responseError(error) { throw error instanceof ApiError ? error : new ApiError(500, error.message || 'Error interno de la simulación.'); }

  async function remoteRequest(path, options) {
    const response = await fetch(API_BASE_URL + path, {
      method: options.method,
      headers: { 'Accept': 'application/json', ...(options.body ? { 'Content-Type': 'application/json' } : {}) },
      credentials: 'include', body: options.body ? JSON.stringify(options.body) : undefined
    });
    let data;
    try { data = await response.json(); } catch (_error) { data = { error: 'El servidor devolvió una respuesta inválida.' }; }
    if (!response.ok) throw new ApiError(response.status, data.error || 'La solicitud no se pudo completar.');
    return { status: response.status, data: data };
  }

  async function mockRequest(path, options) {
    const method = options.method;
    const parsed = pathParts(path);
    const pathname = parsed.pathname;
    const query = parsed.query;
    const state = readState();
    try {
      if (pathname === '/arca/panel' && method === 'GET') {
        const now = new Date(); const month = now.getMonth(); const year = now.getFullYear();
        const contributors = Object.values(state.contributors);
        const invoices = state.invoices;
        const recent = state.audit.slice(0, 8);
        const byRegime = {};
        contributors.forEach((c) => { const r = normRegime(c.regimen && c.regimen.tipo); byRegime[r] = (byRegime[r] || 0) + 1; });
        return jsonResponse(200, {
          altas_mes: contributors.filter((c) => { const d = new Date(c.creado_en); return d.getMonth() === month && d.getFullYear() === year; }).length,
          contribuyentes_por_regimen: byRegime,
          comprobantes_hoy: invoices.filter((i) => new Date(i.fecha_emision).toDateString() === now.toDateString()).length,
          total_facturado: invoices.filter((i) => i.estado === 'emitido' && i.tipo_comprobante.indexOf('FACTURA_') === 0).reduce((s, i) => s + i.monto_total, 0),
          ultimas_operaciones: recent
        });
      }
      if (pathname === '/arca/contribuyentes' && method === 'GET') {
        const term = (query.get('buscar') || '').toLocaleLowerCase();
        const estado = query.get('estado') || '';
        const regimen = query.get('regimen') || '';
        const page = Math.max(1, Number(query.get('page') || 1));
        const all = Object.values(state.contributors).filter((c) => {
          const name = (c.razon_social || [c.apellido, c.nombres].filter(Boolean).join(' ') || '').toLocaleLowerCase();
          return (!term || c.cuit.includes(term) || name.includes(term))
            && (!estado || c.estado === estado)
            && (!regimen || normRegime(c.regimen && c.regimen.tipo) === regimen);
        }).sort((a, b) => (a.razon_social || a.apellido || '').localeCompare(b.razon_social || b.apellido || ''));
        const perPage = 10;
        return jsonResponse(200, { contribuyentes: all.slice((page - 1) * perPage, page * perPage), pagina: page, total: all.length, paginas: Math.max(1, Math.ceil(all.length / perPage)) });
      }
      if (pathname === '/arca/contribuyentes' && method === 'POST') {
        const body = options.body || {};
        const cuit = makeCuit(body);
        if (state.contributors[cuit]) throw new ApiError(409, 'Ya existe un contribuyente con ese CUIT ficticio.');
        const contributor = Object.assign({
          cuit: cuit, estado: 'activo', regimen: null, historial_regimen: [], puntos_venta: [],
          creado_en: isoNow(), creado_por: actor(), ficticio: true
        }, body, { cuit: cuit, creado_en: isoNow(), creado_por: actor(), ficticio: true });
        contributor.actividad_principal = { codigo: String(body.actividad_codigo || ''), descripcion: String(body.actividad_descripcion || '') };
        delete contributor.actividad_codigo; delete contributor.actividad_descripcion;
        state.contributors[cuit] = contributor;
        audit(state, cuit, 'Alta de contribuyente', contributor.tipo_persona);
        writeState(state); return jsonResponse(201, { contribuyente: contributor });
      }
      let match = pathname.match(/^\/arca\/contribuyentes\/([^/]+)(?:\/(constancia|estado|regimen|puntos-venta))?$/);
      if (match) {
        const cuit = match[1];
        const action = match[2] || '';
        const contributor = requireContributor(state, cuit);
        if (!action && method === 'GET') return jsonResponse(200, Object.assign({}, contributor, { auditoria: state.audit.filter((entry) => entry.cuit === cuit) }));
        if (!action && method === 'PATCH') {
          const body = options.body || {};
          const allowed = ['domicilio_fiscal', 'actividad_principal', 'email_dfe'];
          const changes = {};
          allowed.forEach((key) => { if (body[key] !== undefined) changes[key] = body[key]; });
          if (body.nombre_o_razon_social !== undefined) {
            if (contributor.tipo_persona === 'juridica') changes.razon_social = String(body.nombre_o_razon_social).trim();
            else { changes.apellido = String(body.apellido || '').trim(); changes.nombres = String(body.nombres || '').trim(); }
          }
          if (Object.keys(changes).length === 0) throw new ApiError(400, 'No hay campos editables para actualizar.');
          Object.assign(contributor, changes, { actualizado_en: isoNow(), actualizado_por: actor() });
          audit(state, cuit, 'Modificación de datos', Object.keys(changes).join(', ')); writeState(state);
          return jsonResponse(200, { contribuyente: contributor });
        }
        if (action === 'constancia' && method === 'GET') return jsonResponse(200, { contribuyente: contributor, emitida_en: isoNow(), simulacion: true });
        if (action === 'estado' && method === 'POST') {
          const next = options.body && options.body.estado;
          if (!['activo', 'suspendido', 'baja'].includes(next)) throw new ApiError(400, 'El estado debe ser activo, suspendido o baja.');
          const before = contributor.estado; contributor.estado = next; contributor.estado_desde = isoNow();
          audit(state, cuit, 'Cambio de estado', before + ' → ' + next + (options.body.motivo ? ': ' + options.body.motivo : ''));
          writeState(state); return jsonResponse(200, { contribuyente: contributor });
        }
        if (action === 'regimen' && method === 'POST') {
          const body = options.body || {}; const tipo = body.tipo;
          if (!['monotributo', 'responsable_inscripto', 'exento'].includes(tipo)) throw new ApiError(400, 'Régimen no admitido.');
          const amount = Number(body.facturacion_anual_estimada || 0);
          if (!Number.isFinite(amount) || amount < 0) throw new ApiError(400, 'La facturación anual estimada no es válida.');
          const category = tipo === 'monotributo' ? categoryFor(amount) : null;
          const next = { tipo: tipo, impuestos: tipo === 'responsable_inscripto' ? ['IVA', 'Ganancias'] : (tipo === 'monotributo' ? ['Monotributo'] : ['IVA exento']), categoria: category ? category.category : null, facturacion_anual_estimada: amount, limite_anual_ficticio: category ? category.limit : null, desde: isoNow(), ficticio: true };
          contributor.historial_regimen = contributor.historial_regimen || [];
          contributor.historial_regimen.unshift({ anterior: contributor.regimen || null, nuevo: next, fecha: isoNow(), actor: actor() });
          contributor.regimen = next; audit(state, cuit, 'Cambio de régimen', tipo + (category ? ' · categoría ' + category.category : ''));
          writeState(state); return jsonResponse(200, { contribuyente: contributor, categorias_ficticias: CATEGORY_LIMITS });
        }
        if (action === 'puntos-venta' && method === 'GET') return jsonResponse(200, { puntos_venta: contributor.puntos_venta || [] });
        if (action === 'puntos-venta' && method === 'POST') {
          const body = options.body || {};
          if (body.activo === false && body.numero) {
            const pv = contributor.puntos_venta.find((p) => p.numero === String(body.numero).padStart(5, '0'));
            if (!pv) throw new ApiError(404, 'Punto de venta no encontrado.');
            pv.activo = false; pv.baja_en = isoNow(); audit(state, cuit, 'Baja de punto de venta', pv.numero);
            writeState(state); return jsonResponse(200, { punto_venta: pv });
          }
          const number = String(body.numero || '').replace(/\D/g, '').padStart(5, '0');
          if (!/^\d{5}$/.test(number) || number === '00000') throw new ApiError(400, 'El punto de venta debe tener de 1 a 5 dígitos.');
          if ((contributor.puntos_venta || []).some((p) => p.numero === number)) throw new ApiError(409, 'Ese punto de venta ya existe para este CUIT.');
          const pv = { numero: number, sistema_emision: String(body.sistema_emision || 'web'), domicilio: String(body.domicilio || contributor.domicilio_fiscal), activo: true, creado_en: isoNow() };
          contributor.puntos_venta = contributor.puntos_venta || []; contributor.puntos_venta.push(pv);
          audit(state, cuit, 'Alta de punto de venta', number); writeState(state); return jsonResponse(201, { punto_venta: pv });
        }
      }
      if (/^\/padron\/contribuyentes\/[^/]+$/.test(pathname) && method === 'GET') {
        const cuit = pathname.split('/').pop(); const c = requireContributor(state, cuit);
        return jsonResponse(200, { cuit: c.cuit, estado: c.estado, regimen: c.regimen, actividades: [c.actividad_principal], sistemas: ['ARCA (simulado)'] });
      }
      if (pathname === '/arca/comprobantes' && method === 'POST') return await issueInvoice(state, options.body || {});
      if (pathname === '/arca/comprobantes' && method === 'GET') {
        const emitter = query.get('cuit'); const receiver = query.get('receptor'); const from = query.get('desde'); const to = query.get('hasta');
        if (emitter) requireCuit(emitter); if (receiver) requireCuit(receiver);
        const rows = state.invoices.filter((i) => (!emitter || i.cuit === emitter) && (!receiver || i.receptor_cuit === receiver)
          && (!from || i.fecha_emision.slice(0, 10) >= from) && (!to || i.fecha_emision.slice(0, 10) <= to)
          && (!query.get('tipo') || i.tipo_comprobante === query.get('tipo'))
          && (!query.get('numero') || i.numero_comprobante === query.get('numero'))
          && (!query.get('punto_venta') || i.punto_venta === String(query.get('punto_venta')).padStart(5, '0')))
          .sort((a, b) => b.fecha_emision.localeCompare(a.fecha_emision));
        return jsonResponse(200, { comprobantes: rows, total: rows.reduce((s, i) => s + i.monto_total, 0) });
      }
      match = pathname.match(/^\/arca\/comprobantes\/([^/]+)\/nota-(credito|debito)$/);
      if (match && method === 'POST') return await createNote(state, match[1], match[2], options.body || {});
      match = pathname.match(/^\/arca\/comprobantes\/([^/]+)$/);
      if (match && method === 'GET') {
        const key = match[1]; const invoice = state.invoices.find((i) => i.id === key || i.numero_comprobante === key);
        if (!invoice) throw new ApiError(404, 'Comprobante no encontrado.'); return jsonResponse(200, invoice);
      }
      throw new ApiError(404, 'Ruta de demostración no encontrada: ' + method + ' ' + pathname);
    } catch (error) { responseError(error); }
  }

  async function issueInvoice(state, body) {
    const cuit = body.cuit;
    const issuer = requireContributor(state, cuit);
    if (issuer.estado !== 'activo') throw new ApiError(409, 'El emisor debe estar activo para emitir comprobantes.');
    if (!issuer.regimen || !['monotributo', 'responsable_inscripto'].includes(issuer.regimen.tipo)) throw new ApiError(409, 'El emisor necesita inscripción activa en Monotributo o Responsable Inscripto.');
    const pvNumber = String(body.punto_venta || '').replace(/\D/g, '').padStart(5, '0');
    const pv = (issuer.puntos_venta || []).find((item) => item.numero === pvNumber && item.activo);
    if (!pv) throw new ApiError(409, 'El punto de venta debe estar dado de alta y activo para el emisor.');
    let receiver = null;
    if (body.receptor_tipo === 'dni') {
      const dni = String(body.receptor_dni || '').replace(/\D/g, '');
      if (!/^\d{7,8}$/.test(dni)) throw new ApiError(400, 'Para consumidor final ingresá un DNI ficticio de 7 u 8 dígitos.');
      receiver = { tipo: 'consumidor_final', dni: dni, regimen: 'consumidor_final' };
    } else {
      const recipient = requireContributor(state, body.receptor_cuit);
      receiver = { tipo: 'cuit', cuit: recipient.cuit, nombre: recipient.razon_social || [recipient.apellido, recipient.nombres].filter(Boolean).join(' '), regimen: recipient.regimen && recipient.regimen.tipo };
    }
    const autoType = issuer.regimen.tipo === 'monotributo' ? 'FACTURA_C' : (receiver.regimen === 'responsable_inscripto' ? 'FACTURA_A' : 'FACTURA_B');
    if (!Array.isArray(body.items) || body.items.length < 1) throw new ApiError(400, 'Agregá al menos un ítem al comprobante.');
    const items = body.items.map((item) => {
      const quantity = Number(item.cantidad); const price = money(Number(item.precio_unitario)); const rate = Number(item.alicuota_iva);
      if (!Number.isFinite(quantity) || quantity <= 0 || Math.round(quantity * 1000) !== quantity * 1000) throw new ApiError(400, 'La cantidad debe ser positiva y tener hasta 3 decimales.');
      if (![0, 10.5, 21, 27].includes(rate)) throw new ApiError(400, 'La alícuota debe ser 0, 10.5, 21 o 27 %.');
      const net = Math.round(quantity * price * 100) / 100;
      const tax = autoType === 'FACTURA_C' ? 0 : Math.round(net * rate) / 100;
      return { descripcion: String(item.descripcion || 'Ítem').trim().slice(0, 120), cantidad: quantity, precio_unitario: price, alicuota_iva: autoType === 'FACTURA_C' ? 0 : rate, neto: net, iva: tax, total: Math.round((net + tax) * 100) / 100 };
    });
    const neto = items.reduce((s, i) => s + i.neto, 0); const iva = items.reduce((s, i) => s + i.iva, 0);
    const total = Math.round((neto + iva) * 100) / 100;
    if (Number(body.monto_total) !== total) throw new ApiError(409, 'El monto total no coincide con los ítems y el IVA calculado.');
    if (typeof body.id_venta !== 'string' || !body.id_venta.trim()) throw new ApiError(400, 'id_venta es obligatorio.');
    const requestFingerprint = JSON.stringify({ cuit: cuit, receptor: receiver, punto_venta: pvNumber, items: items, tipo_comprobante: autoType });
    const old = state.invoices.find((item) => item.id_venta === body.id_venta.trim());
    if (old) {
      if (old.huella !== requestFingerprint) throw new ApiError(409, 'id_venta ya fue usada con datos diferentes.');
      return jsonResponse(200, Object.assign({}, old, { idempotente: true }));
    }
    const series = cuit + ':' + pvNumber + ':' + autoType;
    const sequence = state.invoices.filter((i) => i.cuit === cuit && i.punto_venta === pvNumber && i.tipo_comprobante === autoType).length + 1;
    const now = new Date(); const expiry = new Date(now.getTime() + 10 * 24 * 60 * 60 * 1000);
    const invoice = {
      id: uid(), id_venta: body.id_venta.trim(), cuit: cuit,
      receptor_cuit: receiver.cuit || null, receptor_dni: receiver.dni || null, receptor_nombre: receiver.nombre || 'Consumidor Final',
      numero_comprobante: String(sequence).padStart(8, '0'), punto_venta: pvNumber, tipo_comprobante: autoType,
      moneda: 'ARS', items: items, neto: Math.round(neto * 100) / 100, iva: Math.round(iva * 100) / 100, monto_total: total,
      cae: 'FICTICIO-' + String(Math.floor(Math.random() * 1e14)).padStart(14, '0'),
      fecha_emision: now.toISOString(), fecha_vencimiento_cae: expiry.toISOString().slice(0, 10),
      estado: 'emitido', simulacion: true, notas_asociadas: [], huella: requestFingerprint
    };
    const qr = await createQr(invoice);
    invoice.qr_data_url = qr;
    state.invoices.push(invoice); audit(state, cuit, 'Emisión de ' + autoType, pvNumber + '-' + invoice.numero_comprobante);
    writeState(state); return jsonResponse(201, invoice);
  }

  async function createQr(invoice) {
    const base = window.location.port === '3004' ? '' : 'http://' + (window.location.hostname || 'localhost') + ':3004';
    const response = await fetch(base + '/arca/qr', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }, body: JSON.stringify({ payload: { version: 1, simulacion: true, fecha: invoice.fecha_emision.slice(0, 10), cuit: invoice.cuit, punto_venta: invoice.punto_venta, tipo_comprobante: invoice.tipo_comprobante, numero: invoice.numero_comprobante, importe: invoice.monto_total, cae: invoice.cae } }) });
    const data = await response.json(); if (!response.ok) throw new ApiError(response.status, data.error || 'No se pudo generar el QR ficticio.');
    return data.data_url;
  }

  async function createNote(state, invoiceId, noteType, body) {
    const original = state.invoices.find((item) => item.id === invoiceId);
    if (!original || original.tipo_comprobante.indexOf('FACTURA_') !== 0) throw new ApiError(404, 'Factura original no encontrada.');
    const amount = money(Number(body.monto_total));
    if (noteType === 'credito' && amount > original.monto_total) throw new ApiError(400, 'La nota de crédito no puede superar el importe de la factura.');
    const typeCode = noteType === 'credito' ? 'NOTA_CREDITO_' : 'NOTA_DEBITO_';
    const type = typeCode + original.tipo_comprobante.slice(-1);
    const pv = original.punto_venta;
    const sequence = state.invoices.filter((i) => i.cuit === original.cuit && i.punto_venta === pv && i.tipo_comprobante === type).length + 1;
    const note = {
      id: uid(), id_venta: 'nota-' + uid(), cuit: original.cuit, receptor_cuit: original.receptor_cuit, receptor_dni: original.receptor_dni,
      numero_comprobante: String(sequence).padStart(8, '0'), punto_venta: pv, tipo_comprobante: type, monto_total: amount,
      neto: amount, iva: 0, moneda: 'ARS', items: [{ descripcion: (body.motivo || 'Ajuste asociado') + ' · Factura ' + original.numero_comprobante, cantidad: 1, precio_unitario: amount, alicuota_iva: 0, neto: amount, iva: 0, total: amount }],
      cae: 'FICTICIO-' + String(Math.floor(Math.random() * 1e14)).padStart(14, '0'), fecha_emision: isoNow(),
      fecha_vencimiento_cae: new Date(Date.now() + 10 * 86400000).toISOString().slice(0, 10), estado: 'emitido', simulacion: true,
      comprobante_asociado_id: original.id, motivo: String(body.motivo || '').slice(0, 250), notas_asociadas: []
    };
    note.qr_data_url = await createQr(note);
    original.notas_asociadas = original.notas_asociadas || []; original.notas_asociadas.push(note.id);
    if (noteType === 'credito' && amount === original.monto_total) original.estado = 'anulado_por_nota_de_credito';
    state.invoices.push(note); audit(state, original.cuit, 'Emisión de nota de ' + noteType, type + ' vinculada a ' + original.numero_comprobante);
    writeState(state); return jsonResponse(201, note);
  }

  async function request(path, options) {
    const opts = Object.assign({ method: 'GET', body: null }, options || {});
    if (MOCK_MODE && path !== '/arca/qr') return mockRequest(path, opts);
    return remoteRequest(path, opts);
  }

  window.ARCAApi = {
    request: request,
    isValidCuit: validCuit,
    makeCuit: makeCuit,
    setActor: function (value) { window.arcaCurrentActor = value || 'Equipo ARCA'; },
    categories: function () { return CATEGORY_LIMITS.slice(); },
    resetDemo: function () { localStorage.removeItem(STORAGE_KEY); return initialState(); }
  };
}());
